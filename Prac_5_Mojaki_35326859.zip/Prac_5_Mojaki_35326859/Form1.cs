﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prac_5_Mojaki_35326859
{
    public partial class Form1 : Form
    {
        private double totalCost;
        private bool specialDiscountFlag = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnRequest_Click(object sender, EventArgs e)
        {


            try
            {
                string category = txtCategory.Text.ToUpper().Trim();
                int numberOfPeople = int.Parse(txtPeople.Text);
                int numberOfDays = int.Parse(txtDays.Text);
                int numberOfPensioners = int.Parse(txtPensioners.Text);
                int numberOfChildren = int.Parse(txtChildren.Text);

                double dailyPrice;
                if (category == "A")
                {
                    dailyPrice = 800;
                }
                else if (category == "B")
                {
                    dailyPrice = 1150;
                }
                else
                {
                    MessageBox.Show("Please enter a valid category (A or B).");
                    return;
                }


                totalCost = dailyPrice * numberOfDays;
                string accommodation = "";

                // Apply discounts based on number of people and days
                if (numberOfPeople >= 5 && numberOfDays >= 3)
                {
                    if (category == "A")
                    {
                        totalCost *= 0.7;
                        accommodation = "Family house";
                    }
                    else
                    {
                        totalCost *= 0.8;
                        accommodation = "Family house";
                    }
                }
                else if (numberOfPeople == 4 && numberOfDays >= 3)
                {
                    if (category == "A")
                    {
                        totalCost *= 0.75;
                        accommodation = "3-bedroom chalet";
                    }
                    else
                    {
                        totalCost *= 0.85;
                        accommodation = "3-bedroom chalet";
                    }
                }
                else
                {
                    accommodation = "2-bedroom chalet";
                }

                // Check for pensioners or children to set the special discount flag
                specialDiscountFlag = (numberOfPensioners > 0 || numberOfChildren > 0);

                // Display the results
                MessageBox.Show($" Please Pay: Total Cost: R{totalCost}\n You are Placed in Accommodation: {accommodation}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter a valid category (A or B).");
            }
        }




        private void btnApply_Click(object sender, EventArgs e)
        {
            int numberOfPensioners = int.Parse(txtPensioners.Text);
            int numberOfChildren = int.Parse(txtChildren.Text);
            if (numberOfPensioners > 0 || numberOfChildren > 0)
            {
                totalCost *= 0.67;
                this.BackColor = System.Drawing.Color.Green;
                MessageBox.Show($"After Special Discount Applied!\nYour new payable Total Cost is: R{totalCost}");
                
            }
            else
            {
                this.BackColor = System.Drawing.Color.Red;
                MessageBox.Show($"No special discount applicable, your payable amount remains: R {totalCost}");
               
            }
        }
    
        private void btnClose_Click(object sender, EventArgs e)
        {
            
                if (this.BackColor == System.Drawing.Color.Green)
                {
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Bring a child or pensioner next time to get better discounts!");
                    this.Close();
                }

            }
        }
}

 